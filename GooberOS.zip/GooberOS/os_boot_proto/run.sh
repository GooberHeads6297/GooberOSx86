#!/bin/bash

qemu-system-i386 -cdrom GooberOSx86.iso
